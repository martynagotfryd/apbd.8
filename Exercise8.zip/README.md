# Exercises6

The tasks to solve are located in the `LinqTasks.cs` class. The tasks should be solved using LINQ syntax.

## Tests
Tests have been added to the task to indicate whether we have correctly solved the given `TaskX`. 